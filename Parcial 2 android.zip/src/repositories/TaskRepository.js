import { supabase } from '../services/supabaseClient';

export default class TaskRepository {
  static async getTasks() {
    const { data, error } = await supabase.from('tasks').select('*');
    if (error) throw error;
    return data;
  }

  static async addTask(task) {
    const { data, error } = await supabase.from('tasks').insert([task]);
    if (error) throw error;
    return data;
  }

  static async updateTask(id, task) {
    const { data, error } = await supabase.from('tasks').update(task).eq('id', id);
    if (error) throw error;
    return data;
  }
}
