import React, { useState } from 'react';
import { View, TextInput, Button } from 'react-native';
import TaskRepository from '../repositories/TaskRepository';

export default function TaskFormScreen({ route, navigation }) {
  const task = route.params?.task;
  const [nombre, setNombre] = useState(task?.nombre || '');
  const [fecha, setFecha] = useState(task?.fecha || '');
  const [responsable, setResponsable] = useState(task?.responsable || '');

  const saveTask = async () => {
    if (task) {
      await TaskRepository.updateTask(task.id, { nombre, fecha, responsable });
    } else {
      await TaskRepository.addTask({ nombre, fecha, responsable });
    }
    navigation.goBack();
  };

  return (
    <View style={{ padding: 20 }}>
      <TextInput placeholder="Nombre" value={nombre} onChangeText={setNombre} style={{ marginBottom: 10, borderWidth: 1, padding: 5 }} />
      <TextInput placeholder="Fecha" value={fecha} onChangeText={setFecha} style={{ marginBottom: 10, borderWidth: 1, padding: 5 }} />
      <TextInput placeholder="Responsable" value={responsable} onChangeText={setResponsable} style={{ marginBottom: 10, borderWidth: 1, padding: 5 }} />
      <Button title="Guardar" onPress={saveTask} />
    </View>
  );
}
