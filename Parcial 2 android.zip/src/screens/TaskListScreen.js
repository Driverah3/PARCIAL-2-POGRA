import React, { useEffect, useState } from 'react';
import { View, Button, Text } from 'react-native';
import TaskRepository from '../repositories/TaskRepository';

export default function TaskListScreen({ navigation }) {
  const [tasks, setTasks] = useState([]);

  useEffect(() => {
    loadTasks();
  }, []);

  const loadTasks = async () => {
    const data = await TaskRepository.getTasks();
    setTasks(data);
  };

  return (
    <View style={{ padding: 20 }}>
      <Button title="Nueva Tarea" onPress={() => navigation.navigate('TaskForm')} />
      {tasks.map(task => (
        <View key={task.id} style={{ marginVertical: 10, padding: 10, borderWidth: 1 }}>
          <Text>Nombre: {task.nombre}</Text>
          <Text>Fecha: {task.fecha}</Text>
          <Text>Responsable: {task.responsable}</Text>
          <Button title="Editar" onPress={() => navigation.navigate('TaskForm', { task })} />
        </View>
      ))}
    </View>
  );
}
