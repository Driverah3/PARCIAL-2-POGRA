import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://TU_URL.supabase.co';
const SUPABASE_KEY = 'TU_API_KEY';

export const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);
